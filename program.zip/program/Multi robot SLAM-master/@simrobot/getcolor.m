function color = getcolor(simrobot);
% GETCOLOR	(system) returns [r g b] triplet defining robot color
%		See also SETCOLOR.

color = simrobot.color;