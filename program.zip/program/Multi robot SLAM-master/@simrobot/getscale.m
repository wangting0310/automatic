function scale = getscale(simrobot);
% GETSCALE	(system) returns robot scale.
%		See also SETSCALE.

scale = simrobot.scale;
