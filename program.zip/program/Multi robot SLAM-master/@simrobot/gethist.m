function history = gethist(simrobot);
% GETHIST 	(system) returns replay data.
%		See also DELHIST, SETHIST.

history = simrobot.history ;
