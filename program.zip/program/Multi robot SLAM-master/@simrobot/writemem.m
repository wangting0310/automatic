function new = writemem(simrobot,userdata);
% WRITEMEM	writes data to the robot's memory.
%		See also READMEM.

simrobot.userdata = userdata;

new = simrobot;