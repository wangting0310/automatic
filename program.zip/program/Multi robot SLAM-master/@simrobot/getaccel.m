function accel = getaccel(simrobot);
% GETACCEL	returns acceleration of left and right wheel of the robot.
%		See also SETACCEL.
accel = simrobot.accel;