function answer = readmem(simrobot)
% READMEM	reads data from memory of the robot.
%		See also WRITEMEM.

answer = simrobot.userdata;