function status = getcrashed(simrobot);

status = simrobot.crashed;
