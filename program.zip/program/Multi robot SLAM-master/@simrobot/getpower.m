function power = getpower(simrobot);
% GETPOWER	returns "power switch state".
%		See also SETPOWER.

power = simrobot.power;
