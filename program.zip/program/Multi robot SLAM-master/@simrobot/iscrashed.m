function crashed = iscrashed(simrobot);
% ISCRASHED	returns crash-flag state.


crashed = simrobot.crashed;
