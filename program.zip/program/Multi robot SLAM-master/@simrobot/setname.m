function new = setname(simrobot, name);
% SETNAME 	(system) sets new robot name.
%		See also GETNAME.

simrobot.name = name;

new = simrobot;
