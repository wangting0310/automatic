function data = getdata(simrobot);
% GETCOL	returns [r g b] triplet defining robot color
%		See also SETCOLOR.

data = simrobot.userdata;