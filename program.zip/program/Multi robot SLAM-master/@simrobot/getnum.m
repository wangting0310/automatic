function number = getnum(simrobot);
% GETNUM	returns ID number of the robot.
%		See also SETNUM.

number = simrobot.number;
