function name = getnameR(simrobot);
% GETNAME	returns name of the robot.
%		See also SETNAME.

name = simrobot.name;
