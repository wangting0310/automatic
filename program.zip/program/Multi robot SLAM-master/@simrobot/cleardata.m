function new = setdata(simrobot);
% SETCOLOR	changes color of the robot.
%		See also GETCOLOR.

simrobot.userdata=[];

new = simrobot;