function new = clearcf(simrobot);

simrobot.crashed = 0;

new = simrobot;
