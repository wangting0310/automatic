function new = setnum(simrobot, number);
% SETNUM 	(system) assigns new ID number to the robot.
%		See also GETNUM.

simrobot.number = number;

new = simrobot;
