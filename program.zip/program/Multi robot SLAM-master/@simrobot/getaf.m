function af = getaf(simrobot);
% GETAF		(system) returns algorithm filename.
%		See also SETAF.

af = simrobot.af;
