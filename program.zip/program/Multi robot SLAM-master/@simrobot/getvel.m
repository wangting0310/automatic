function velocity = getvel(simrobot);	
% GETVEL	returns angular velocity of left and right wheel in two-element vector.
%		See also SETVEL, GETACCEL, SETACCEL.

velocity = simrobot.velocity;
