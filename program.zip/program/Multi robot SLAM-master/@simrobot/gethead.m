function heading = gethead(simrobot);
% GETHEAD	returns actual heading of the robot
%		See also SETHEAD, GETPOS, SETPOS.

heading = simrobot.heading;
