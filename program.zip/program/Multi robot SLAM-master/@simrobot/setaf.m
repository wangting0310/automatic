function new = setaf(simrobot,af);
% SETAF		(system) assigns new algortihm filename to the robot.
%		See also GETAF.

simrobot.af = af;

new = simrobot;