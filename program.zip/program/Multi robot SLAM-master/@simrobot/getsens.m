function sensors = getsens(simrobot);
% GETSENS	(system) returns sensors structure.
%		See also ADDSENS, ADDSENSS.

sensors = simrobot.sensors;