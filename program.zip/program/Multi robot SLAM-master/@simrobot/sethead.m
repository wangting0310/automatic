function new = sethead(simrobot, heading);
% SETHEAD	(system) sets heading of the robot.
%		See also GETHEAD.

simrobot.heading = heading;

new = simrobot;
