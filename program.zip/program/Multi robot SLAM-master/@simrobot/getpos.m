function position = getpos(simrobot);
% GETPOS	returns actual position of the robot in the virtual environment.
%		See also SETPOS.

position = simrobot.position;
